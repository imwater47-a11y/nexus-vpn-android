package com.nexusvpn.app

data class VpnServer(
    val id: String,
    val country: String,
    val city: String,
    val flag: String,
    val region: String,
    val latencyMs: Int,
    val loadPercent: Int,
    val isAvailable: Boolean = true
)

object ServerCatalog {
    val servers = listOf(
        VpnServer("us-ny", "United States", "New York", "🇺🇸", "Americas", 42, 28),
        VpnServer("uk-lon", "United Kingdom", "London", "🇬🇧", "Europe", 116, 41),
        VpnServer("de-fra", "Germany", "Frankfurt", "🇩🇪", "Europe", 132, 35),
        VpnServer("jp-tok", "Japan", "Tokyo", "🇯🇵", "Asia Pacific", 94, 22),
        VpnServer("sg-sin", "Singapore", "Singapore", "🇸🇬", "Asia Pacific", 38, 19),
        VpnServer("in-mum", "India", "Mumbai", "🇮🇳", "Asia Pacific", 18, 16),
        VpnServer("fr-par", "France", "Paris", "🇫🇷", "Europe", 124, 31),
        VpnServer("nl-ams", "Netherlands", "Amsterdam", "🇳🇱", "Europe", 128, 25),
        VpnServer("ca-tor", "Canada", "Toronto", "🇨🇦", "Americas", 208, 37),
        VpnServer("au-syd", "Australia", "Sydney", "🇦🇺", "Asia Pacific", 176, 29),
        VpnServer("kr-sel", "South Korea", "Seoul", "🇰🇷", "Asia Pacific", 108, 33),
        VpnServer("ch-zrh", "Switzerland", "Zurich", "🇨🇭", "Europe", 139, 17),
        VpnServer("br-sao", "Brazil", "São Paulo", "🇧🇷", "Americas", 286, 44),
        VpnServer("ae-dxb", "UAE", "Dubai", "🇦🇪", "Middle East", 79, 26)
    )
}
