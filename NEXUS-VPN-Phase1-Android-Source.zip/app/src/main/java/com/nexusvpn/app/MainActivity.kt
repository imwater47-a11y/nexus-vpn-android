package com.nexusvpn.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF080D17)
private val Panel = Color(0xFF121C2B)
private val Panel2 = Color(0xFF1A293B)
private val Lime = Color(0xFF9CF45B)
private val Muted = Color(0xFF91A0B5)
private val White = Color(0xFFF4F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }
}

@Composable
fun NexusApp() {
    var selected by remember { mutableStateOf(ServerCatalog.servers.first { it.id == "sg-sin" }) }
    var connected by remember { mutableStateOf(false) }
    var demoMode by remember { mutableStateOf(true) }
    var showServers by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Lime, background = Ink, surface = Panel,
            onPrimary = Ink, onBackground = White, onSurface = White
        )
    ) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101D2C), Ink)))) {
            Column(
                modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Lime.copy(alpha = .13f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Shield, null, tint = Lime, modifier = Modifier.size(25.dp))
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("NEXUS VPN", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = White, letterSpacing = 1.2.sp)
                        Text("PRIVATE • GLOBAL • SIMPLE", fontSize = 9.sp, color = Muted, letterSpacing = 1.5.sp)
                    }
                    IconButton(onClick = { showInfo = true }) { Icon(Icons.Default.Info, "About", tint = Muted) }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Your connection", color = Muted, fontSize = 13.sp)
                        Text(if (connected) "Protected session" else "Ready when you are", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(color = if (connected) Lime.copy(alpha = .15f) else Color.White.copy(alpha = .07f), shape = CircleShape) {
                        Row(Modifier.padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(7.dp).background(if (connected) Lime else Muted, CircleShape))
                            Spacer(Modifier.width(7.dp))
                            Text(if (connected) "CONNECTED" else "DISCONNECTED", color = if (connected) Lime else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.size(214.dp).background(
                            Brush.radialGradient(listOf(Lime.copy(alpha = .16f), Color.Transparent)),
                            CircleShape
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(174.dp).background(Color(0xFF142638), CircleShape), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(150.dp).background(Color(0xFF10202D), CircleShape), contentAlignment = Alignment.Center) {
                                Surface(
                                    onClick = { connected = !connected },
                                    modifier = Modifier.size(124.dp),
                                    shape = CircleShape,
                                    color = if (connected) Color(0xFF244D3A) else Color(0xFF1B382F),
                                    border = androidx.compose.foundation.BorderStroke(2.dp, Lime.copy(alpha = .85f))
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Icon(Icons.Default.PowerSettingsNew, null, tint = Lime, modifier = Modifier.size(34.dp))
                                        Spacer(Modifier.height(5.dp))
                                        Text(if (connected) "DISCONNECT" else "CONNECT", color = White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                Surface(
                    onClick = { showServers = true },
                    color = Panel,
                    shape = RoundedCornerShape(22.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .06f))
                ) {
                    Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(selected.flag, fontSize = 34.sp)
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("SELECTED LOCATION", color = Muted, fontSize = 9.sp, letterSpacing = 1.3.sp)
                            Text(selected.country, color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("${selected.city}  •  ${selected.latencyMs} ms estimated", color = Muted, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Lime)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("PING", if (connected) "${selected.latencyMs} ms" else "--", Modifier.weight(1f))
                    MetricCard("DOWNLOAD", if (connected) "Demo" else "0 MB", Modifier.weight(1f))
                    MetricCard("UPLOAD", if (connected) "Demo" else "0 MB", Modifier.weight(1f))
                }

                Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Testing mode", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Simulated UI state only • no VPN tunnel", color = Muted, fontSize = 10.sp)
                        }
                        Switch(checked = demoMode, onCheckedChange = { demoMode = it }, enabled = !connected)
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("NEXUS VPN  •  PHASE 1 BUILD", color = Color(0xFF64758B), fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 12.dp))
            }
        }

        if (showServers) {
            ModalBottomSheet(onDismissRequest = { showServers = false }, containerColor = Panel) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                    Text("Choose a location", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Locations are catalogue entries; availability is not live yet.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 14.dp))
                    LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
                        items(ServerCatalog.servers) { server ->
                            Row(
                                Modifier.fillMaxWidth().clickable { selected = server; connected = false; showServers = false }
                                    .padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(server.flag, fontSize = 28.sp)
                                Spacer(Modifier.width(13.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(server.country, color = White, fontWeight = FontWeight.SemiBold)
                                    Text(server.city, color = Muted, fontSize = 11.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${server.latencyMs} ms*", color = Lime, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("sample value", color = Muted, fontSize = 9.sp)
                                }
                                if (selected.id == server.id) Icon(Icons.Default.CheckCircle, null, tint = Lime, modifier = Modifier.padding(start = 8.dp))
                            }
                            HorizontalDivider(color = Color.White.copy(alpha = .06f))
                        }
                    }
                }
            }
        }

        if (showInfo) {
            AlertDialog(
                onDismissRequest = { showInfo = false },
                containerColor = Panel,
                title = { Text("About this build", color = White) },
                text = { Text("Phase 1 is a visual Android prototype. Connect toggles a local demo state only. It does not create encryption, change your IP address, or route traffic. Real WireGuard support is a separate integration phase.", color = Muted) },
                confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Got it", color = Lime) } }
            )
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
            Text(value, color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
