package com.nexusvpn.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ServerCatalogTest {
    @Test fun serverIdsAreUnique() {
        val ids = ServerCatalog.servers.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun serverLatencyAndLoadAreWithinDisplayRange() {
        assertTrue(ServerCatalog.servers.all { it.latencyMs > 0 && it.loadPercent in 0..100 })
    }

    @Test fun initialCatalogueHasMultipleRegions() {
        assertTrue(ServerCatalog.servers.map { it.region }.toSet().size >= 3)
    }
}
