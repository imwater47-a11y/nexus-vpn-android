# NEXUS VPN — Android Phase 1

A Kotlin + Jetpack Compose Android UI prototype for the NEXUS VPN project.

## Important scope and safety note

This Phase 1 app is **not a working VPN**. The Connect button changes local demo UI state only. It does not establish a tunnel, encrypt traffic, change the device IP address, or provide privacy protection. Server entries and latency values are sample catalogue data, not live infrastructure.

The real VPN engine is planned for Phase 2 using the official WireGuard Android tunnel library and a provisioned WireGuard server. Do not present the current build as offering VPN protection.

## Requirements

- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35
- Android device or emulator running Android 8.0 (API 26) or newer

## Open and run

1. Extract the ZIP.
2. Open the `NexusVPN-Phase1` folder in Android Studio.
3. Allow Gradle sync to complete.
4. Select an emulator or connect an Android phone with USB debugging enabled.
5. Press **Run**.

If Android Studio asks to install SDK Platform 35 or Build Tools, accept the installation.

## Included in Phase 1

- Dark premium NEXUS VPN interface
- Country and city picker
- 14 sample server catalogue entries
- Selected location state
- Explicit demo/testing mode
- Clear disclosure that the tunnel is not active
- Unit tests for catalogue integrity

## Run tests

In Android Studio: app > Tasks > verification > testDebugUnitTest.

Or from the project root, if Gradle is installed:

```bash
gradle test
```

## Phase 2 — real WireGuard integration

Before real tunnel functionality can be enabled:

1. Add the WireGuard Android tunnel dependency from its official maintained distribution.
2. Implement Android `VpnService` permission consent and tunnel lifecycle.
3. Obtain a WireGuard client configuration securely from the backend.
4. Provision at least one Linux WireGuard node with a real public endpoint and allocated address pool.
5. Store private keys on-device using Android Keystore-backed storage; never send client private keys to the API.
6. Implement server health, peer provisioning, revocation, and key rotation.
7. Add fail-closed handling, DNS routing, IPv4/IPv6 leak tests, reconnect behavior, and foreground-service notification.
8. Verify Android platform and Google Play policy requirements before release.

## Production scale

10,000 simultaneous tunnels is a capacity target, not a guarantee. Validate per-region bandwidth, packet throughput, CPU, memory, file descriptors, provider limits, NAT behavior, and peak traffic with staged load tests. A small inexpensive test node is appropriate for development; it is not suitable for a 10,000-user launch.

## Suggested next architecture

- Android: Kotlin, Jetpack Compose, WireGuard tunnel backend
- API: Go, REST, authenticated device registration
- Data: PostgreSQL, Redis
- Infrastructure: multi-region Linux nodes, infrastructure-as-code, secrets manager
- Observability: Prometheus, Grafana, centralized logs
- Admin: separate authenticated web console with MFA and RBAC
